# Tugas UAS Pemrograman Mobile 2

### | Stephen Pratama Kurnia | TI.22.A5 | 312210635 |

Video Presentasi :
https://youtu.be/Jpsz5snLwWA
